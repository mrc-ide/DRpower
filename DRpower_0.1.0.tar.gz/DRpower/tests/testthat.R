library(testthat)
library(DRpower)

test_check("DRpower")
