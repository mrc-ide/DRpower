## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(kableExtra)
library(dplyr)
library(ggplot2)
library(tidyverse)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
# filter to a single parameter combination
df_filtered <- df_sim %>%
  filter(prior_ICC_shape2 == 9) %>%
  filter(prev_thresh == 0.05) %>%
  filter(ICC == 0.05) %>%
  filter(n_clust == 6) %>%
  filter(near(prevalence, 0.1))

# calculate power by z-test for same parameters
df_ztest <- data.frame(n = 5:200) %>%
  mutate(n_clust = 6,
         N = n*n_clust,
         p = 0.1,
         mu = 0.05,
         ICC = 0.05,
         Deff = 1 + (n - 1)*ICC,
         power = pnorm(abs(p - mu) / sqrt(Deff * p*(1 - p) / N) - qnorm(1 - 0.05/2)))

# plot power as a function of sample size for both methods
df_filtered %>%
  ggplot() + theme_bw() +
  geom_hline(yintercept = 0.8, col = grey(0.6)) +
  geom_linerange(aes(x = N, ymin = power_lower, ymax = power_upper)) +
  geom_line(aes(x = N, y = power_mean, colour = "DRpower")) +
  geom_line(aes(x = n, y = power, colour = "z-test"), data = df_ztest) +
  scale_color_manual(values = c("black", "red"), name = "Method") +
  xlim(c(0, 200)) + ylim(c(0, 1)) +
  xlab("Sample size per cluster") + ylab("Power") +
  ggtitle("Assumptions:\nclusters = 5, prevalence = 10%, ICC = 0.05")

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
df_ss %>%
  filter(prior_ICC_shape2 == 9) %>%
  filter(ICC == 0.05) %>%
  filter(prev_thresh == 0.05) %>%
  filter(prevalence >= 0.08) %>%
  mutate(prevalence = prevalence * 100) %>%
  select(n_clust, prevalence, N_opt) %>%
  pivot_wider(names_from = prevalence, values_from = N_opt) %>%
  kbl(format = "html", table.attr = "style='width:100%;'",
      caption = "Table of minimum sample size required per cluster in order to achieve 80% power. Columns give the assumed true prevalence of deletions (as %), rows give the number of clusters (n_clust).") %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed"),
                full_width = TRUE) %>%
  row_spec(0, extra_css = "border-bottom: 1px solid; border-top: 1px solid") %>%
  row_spec(19, extra_css = "border-bottom: 1px solid")

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
expand_grid(p = seq(0.08, 0.20, 0.01),
            n_clust = 2:20,
            n = 5:2e3) %>%
  mutate(N = n*n_clust,
         mu = 0.05,
         ICC = 0.05,
         Deff = 1 + (n - 1)*ICC,
         power = pnorm(abs(p - mu) / sqrt(Deff * p*(1 - p) / N) - qnorm(1 - 0.05/2)),
         p = p * 100) %>%
  group_by(p, n_clust) %>%
  summarise(N_opt = ifelse(any(power > 0.8), n[which(power > 0.8)[1]], NA)) %>%
  pivot_wider(names_from = p, values_from = N_opt) %>%
  kbl(format = "html", table.attr = "style='width:100%;'",
      caption = "Table of minimum sample size required under the z-test analysis plan (NOT ADVISED).") %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed"),
                full_width = TRUE) %>%
  row_spec(0, extra_css = "border-bottom: 1px solid; border-top: 1px solid") %>%
  row_spec(19, extra_css = "border-bottom: 1px solid")

