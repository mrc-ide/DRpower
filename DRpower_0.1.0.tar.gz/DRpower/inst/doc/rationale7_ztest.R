## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(kableExtra)
library(dplyr)
library(ggplot2)

## -----------------------------------------------------------------------------
N <- 600
p <- 0.08
mu <- 0.05
Deff <- 1.5

pnorm(abs(p - mu) / sqrt(Deff * p*(1 - p) / N) - qnorm(1 - 0.05/2))

## ---- echo=FALSE--------------------------------------------------------------
p <- 0.032
Deff <- 1.5

#(qnorm(0.8) + qnorm(1 - 0.05/2))^2 * p*(1 - p) / (p - 0.05)^2 * Deff

