## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(ggridges)
library(kableExtra)
library(tidyverse)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
# subset to ADMIN1 regions that have data for 3 or more lower geographical units
# in the same year
multi_site <- historical_data %>%
  group_by(Paper_name, WHO_country_name, WHO_ADMIN1, Year) %>%
  summarise(unique_count = n()) %>%
  ungroup() %>%
  filter(unique_count >= 3) %>%
  mutate(study_ID = seq_along(unique_count)) %>%
  mutate(plot_name = sprintf("%s: %s\n(%s)", WHO_country_name, WHO_ADMIN1, Paper_name))

# make table
multi_site %>%
  left_join(studies_inclusion) %>%
  select(Paper_name, WHO_country_name, WHO_ADMIN1, Year, unique_count, Paper_link) %>%
  rename(Study_name = Paper_name,
         Country = WHO_country_name,
         ADMIN1 = WHO_ADMIN1,
         Num_sites = unique_count) %>%
  kable() %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed")) %>%
  row_spec(0, extra_css = "border-bottom: 1px solid; border-top: 1px solid") %>%
  row_spec(6, extra_css = "border-bottom: 1px solid") %>%
  scroll_box(width = "700px", height = "300px")


## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
# merge dataset and finalise
dat_final <- multi_site %>%
  left_join(historical_data)

# make table
dat_final %>%
  select(Paper_name, WHO_country_name, WHO_ADMIN1, WHO_ADMIN2, WHO_village_or_health_facility,
         Year, Tested, Count_deletions) %>%
  rename(Study_name = Paper_name,
         Country = WHO_country_name,
         ADMIN1 = WHO_ADMIN1,
         ADMIN2 = WHO_ADMIN2,
         Site = WHO_village_or_health_facility,
         Deletions = Count_deletions) %>%
  kable() %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed")) %>%
  row_spec(0, extra_css = "border-bottom: 1px solid; border-top: 1px solid") %>%
  row_spec(29, extra_css = "border-bottom: 1px solid") %>%
  scroll_box(width = "700px", height = "300px")

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
# loop through studies and get full posterior in each case
x <- seq(0, 1, l = 1001)
l <- list()
for (i in 1:nrow(multi_site)) {
  
  # subset to this study and get raw posterior ICC
  dat_sub <- dat_final %>%
    filter(study_ID == multi_site$study_ID[i])
  post_df <- get_ICC(n = dat_sub$Count_deletions, N = dat_sub$Tested,
                     prior_ICC_shape2 = 1, n_intervals = 100,
                     post_full_on = TRUE, post_full_breaks = x)
  
  # save results
  y <- post_df$post_full[[1]]
  l[[i]] <- data.frame(col = "data",
                       group = multi_site$plot_name[i],
                       x = x,
                       y = y / sum(y))
}
df1 <- l %>%
  bind_rows()

# plot
df1 %>%
  mutate(group = factor(group, levels = c(multi_site$plot_name))) %>%
  ggplot() + theme_bw() +
  geom_ridgeline(aes(x = x, y = group, height = y, group = group, fill = col),
                 scale = 40) +
  xlim(c(0, 0.5)) +
  xlab("Intra-cluster correlation") + ylab("Probability density") +
  guides(fill = "none")

## ---- echo=FALSE, message=FALSE, warning=FALSE, fig.height=2.5, fig.width=5----
# add combined posterior
post_comb <- df1 %>%
  pivot_wider(names_from = group, values_from = y) %>%
  select(-c(col, x)) %>%
  apply(1, prod)

df1 <- rbind(df1, data.frame(col = "posterior",
                             group = "Combined posterior",
                             x = x,
                             y = post_comb / sum(post_comb)))

df1 %>%
  filter(group == "Combined posterior") %>%
  ggplot() + theme_bw() +
  geom_ridgeline(aes(x = x, y = group, height = y, group = group, fill = col),
                 scale = 40) +
  xlim(c(0, 0.5)) + scale_y_discrete(expand = c(0, 0)) +
  xlab("Intra-cluster correlation") + ylab("Probability density") +
  guides(fill = "none")

## ---- echo=FALSE, message=FALSE, warning=FALSE, fig.height=2.5, fig.width=5----
# add default prior
y <- dbeta(x, shape1 = 1, shape2 = 9)
df1 <- rbind(df1, data.frame(col = "prior",
                             group = "Default prior",
                             x = x,
                             y = y / sum(y)))

df1 %>%
  filter(group == "Default prior") %>%
  ggplot() + theme_bw() +
  geom_ridgeline(aes(x = x, y = group, height = y, group = group, fill = col),
                 scale = 40) +
  xlim(c(0, 0.5)) + scale_y_discrete(expand = c(0, 0)) +
  xlab("Intra-cluster correlation") + ylab("Probability density") +
  guides(fill = "none")

