## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(kableExtra)

## ---- echo=FALSE, message=FALSE, warnings=FALSE-------------------------------
rbind.data.frame(list(Parameter = "$p$", Definition = "Prevalence at the province level. This is usually the main thing we are interested in estimating")) %>%
  rbind.data.frame(list(Parameter = "$r$", Definition = "Intra-cluster correlation coefficient (between 0 and 1)")) %>%
  rbind.data.frame(list(Parameter = "$\\alpha$, $\\beta$", Definition = "Shape parameters of beta prior on cluster-level prevalence. Defined based on other model parameters as follows:<br>$\\alpha = p(1/r - 1)$<br>$\\beta = (1 - p)(1/r - 1)$")) %>%
  rbind.data.frame(list(Parameter = "$c$", Definition = "Number of clusters (sites)")) %>%
  rbind.data.frame(list(Parameter = "$x_i$", Definition = "Prevalence in cluster $i$")) %>%
  rbind.data.frame(list(Parameter = "$n_i$", Definition = "Total sample size in cluster $i$")) %>%
  rbind.data.frame(list(Parameter = "$k_i$", Definition = "Observed pfhrp2/3 deletions in cluster $i$")) %>%
  kable(format = "html", escape = F) %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed")) %>%
  row_spec(0, extra_css = "border-bottom: 1px solid; border-top: 1px solid") %>%
  row_spec(2, extra_css = "border-bottom: 1px solid") %>%
  scroll_box(width = "800px", height = "380px")

