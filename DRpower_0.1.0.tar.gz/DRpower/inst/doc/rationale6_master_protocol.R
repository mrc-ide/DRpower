## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(kableExtra)
library(dplyr)
library(ggplot2)

## ---- echo=FALSE, fig.width=5, fig.height=4-----------------------------------
data.frame(y = as.factor(1:3), x = c(6, 8, 2.5)) %>%
  ggplot() + theme_bw() +
  geom_errorbar(aes(x = x, y = y, xmin = x - 2, xmax = x + 2), width = 0.1) +
  geom_point(aes(x = x, y = y)) +
  geom_vline(xintercept = 5, linetype = "dashed") +
  xlim(c(0, 15)) +
  xlab("Prevalence of deletions (%)") + ylab("") +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  annotate(geom = "text", x = c(6, 8, 2.5) + 3, y = 1:3, hjust = 0, label = sprintf("Outcome %s", 3:1))

## -----------------------------------------------------------------------------
p <- 0.08
Deff <- 1.5
z <- qnorm(1 - 0.05/2)

Deff * z^2 * p * (1 - p) / (p - 0.05)^2

## -----------------------------------------------------------------------------
p <- 0.032
Deff <- 1.5
z <- qnorm(1 - 0.05/2)

Deff * z^2 * p * (1 - p) / (p - 0.05)^2

## -----------------------------------------------------------------------------
# specify assumed values
N <- 315
p <- 0.08
z <- qnorm(1 - 0.05/2)

# calculate the lower CI for every possible observed number of deletions
p_est <- (0:N) / N
CI_lower <- p_est - z * sqrt(p_est * (1 - p_est) / N)

# establish if we get a conclusive high prevalence result for each possible
# number of deletions, and weight this by the chance of each result to get the
# total power
conclude_high <- (CI_lower > 0.05)
exact_power <- sum(conclude_high * dbinom(0:N, N, p))

exact_power

## -----------------------------------------------------------------------------
N <- 472  # we will assume 8 clusters of 59 so we can hit this value exactly
p <- 0.08
z <- qnorm(1 - 0.05/2)
Deff <- 1.5
ICC <- (Deff - 1) / (59 - 1) # the ICC that corresponds to this Deff

# simulate a large number of times
set.seed(1)
CI_lower <- rep(NA, 1e5)
for (i in seq_along(CI_lower)) {
  
  # draw from a beta-binomial model with the chosen level of ICC
  x <- DRpower:::rbbinom_reparam(n_clust = 8, N = 59, p = p, rho = ICC)
  
  # calculate CIs taking into account the design effect
  p_est <- sum(x) / N
  CI_lower[i] <- p_est - z * sqrt(Deff * p_est * (1 - p_est) / N)
}

# how often is the lower CI above the 5% threshold
sim_power <- mean(CI_lower > 0.05)

sim_power

## ---- echo=FALSE--------------------------------------------------------------
N <- 600
p <- 0.08
z <- qnorm(1 - 0.05/2)
Deff <- 1.5
ICC <- (Deff - 1) / (60 - 1)

set.seed(1)
CI_lower <- rep(NA, 1e5)
for (i in seq_along(CI_lower)) {
  x <- DRpower:::rbbinom_reparam(n_clust = 10, N = 60, p = p, rho = ICC)
  p_est <- sum(x) / N
  CI_lower[i] <- p_est - z * sqrt(Deff * p_est * (1 - p_est) / N)
}
message("empirical power:")
mean(CI_lower > 0.05)

