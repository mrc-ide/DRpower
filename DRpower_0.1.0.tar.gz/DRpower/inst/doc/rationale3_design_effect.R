## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(kableExtra)
library(tidyverse)

## ---- echo=FALSE--------------------------------------------------------------
df_ex <- data.frame(cluster = 1:5,
           n_tested = 50,
           n_deletions = c(15, 10, 1, 2, 7)) %>%
  dplyr::mutate(cluster_prevalence = n_deletions / n_tested * 100)

n_tested <- df_ex$n_tested
n_deletions <- df_ex$n_deletions
c <- nrow(df_ex)
n <- df_ex$n_tested[1]
p <- mean(df_ex$cluster_prev / 100)
z <- qnorm(0.975)
d <- z * sqrt(p * (1 - p) / (n*c))
Wald_lower <- (p - d)*100
Wald_upper <- (p + d)*100

## ---- echo=FALSE--------------------------------------------------------------
d <- z * sd(df_ex$cluster_prevalence) / sqrt(c)
standard_lower <- p*100 - d
standard_upper <- p*100 + d

## ---- echo=FALSE--------------------------------------------------------------
v1 <- var(df_ex$cluster_prevalence / 100) / c
v2 <- p*(1 - p) / (n*c)
Deff <- v1 / v2
Neff <- n*c / Deff

