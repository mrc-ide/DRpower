## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(kableExtra)
library(dplyr)
library(ggplot2)


## ---- message=FALSE, warning=FALSE--------------------------------------------
# load tidyverse package for manipulating data
library(tidyverse)

# filter sample size data.frame
df_ss %>%
  filter(prior_ICC_shape2 == 9) %>%
  filter(ICC == 0.05) %>%
  filter(prev_thresh == 0.05) %>%
  filter(near(prevalence, 0.1)) %>%
  select(n_clust, N_opt)  # show just these two columns

## ---- message=FALSE, warning=FALSE--------------------------------------------
# filter data
df_sim_filter <- df_sim %>%
  filter(prior_ICC_shape2 == 9) %>%
  filter(n_clust == 6) %>%
  filter(ICC == 0.05) %>%
  filter(prev_thresh == 0.05) %>%
  filter(near(prevalence, 0.1))

# plot power as a function of N
df_sim_filter %>%
  ggplot() + theme_bw() +
  geom_point(aes(x = N, y = power_mean)) +
  geom_hline(yintercept = 0.8, alpha = 0.5) +
  xlim(c(0, 150)) + ylim(c(0, 1))

## ---- echo=FALSE--------------------------------------------------------------
set.seed(1)

## -----------------------------------------------------------------------------
get_power_threshold(N = c(113, 113, 60, 60, 40, 40),   # new cluster sizes
                    prevalence = 0.1,
                    ICC = 0.05,
                    prev_thresh = 0.05,
                    reps = 1000)

## ---- echo=FALSE--------------------------------------------------------------
set.seed(1)

## -----------------------------------------------------------------------------
get_power_threshold(N = c(250, 250, 60, 60, 40, 40),   # rebalanced cluster sizes
                    prevalence = 0.1,
                    ICC = 0.05,
                    prev_thresh = 0.05,
                    reps = 1000)

## ---- echo=FALSE--------------------------------------------------------------
set.seed(1)

## -----------------------------------------------------------------------------
get_power_threshold(N = c(113, 113, 60, 60, 40, 40, 40),   # one more cluster of size 40
                    prevalence = 0.1,
                    ICC = 0.05,
                    prev_thresh = 0.05,
                    reps = 1000)

## -----------------------------------------------------------------------------
# final sample sizes per cluster
N <- c(250, 250, 60, 60, 40, 40)

## -----------------------------------------------------------------------------
N_suspected <- ceiling(N / 0.4)

print(N_suspected)

## -----------------------------------------------------------------------------
N_final <- ceiling(N_suspected / 0.9)

print(N_final)

