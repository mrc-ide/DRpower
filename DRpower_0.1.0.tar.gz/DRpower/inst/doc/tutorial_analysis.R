## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(kableExtra)
library(tidyverse)

## -----------------------------------------------------------------------------
# define observed data
num_deletions <- c(3, 12, 4)
sample_size <- c(100, 130, 65)

# estimate prevalence
get_prevalence(n = num_deletions,
               N = sample_size)

## -----------------------------------------------------------------------------
# estimate ICC
get_ICC(n = num_deletions,
        N = sample_size)

