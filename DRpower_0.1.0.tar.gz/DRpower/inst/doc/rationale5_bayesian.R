## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(DRpower)
library(kableExtra)
library(dplyr)
library(ggplot2)

## ---- echo=FALSE--------------------------------------------------------------
df_ex <- data.frame(cluster = 1:5,
           n_tested = 50,
           n_deletions = c(15, 10, 1, 2, 7)) %>%
  dplyr::mutate(cluster_prevalence = n_deletions / n_tested * 100)

n_tested <- df_ex$n_tested
n_deletions <- df_ex$n_deletions
c <- nrow(df_ex)
n <- df_ex$n_tested[1]
p <- mean(df_ex$cluster_prev / 100)
z <- qnorm(0.975)
d <- z * sqrt(p * (1 - p) / (n*c))
Wald_lower <- (p - d)*100
Wald_upper <- (p + d)*100

## ---- echo=FALSE--------------------------------------------------------------
d <- z * sd(df_ex$cluster_prevalence) / sqrt(c)
standard_lower <- p*100 - d
standard_upper <- p*100 + d

## ---- echo=FALSE--------------------------------------------------------------
v1 <- var(df_ex$cluster_prevalence / 100) / c
v2 <- p*(1 - p) / (n*c)
Deff <- v1 / v2
Neff <- n*c / Deff

## ---- echo=FALSE--------------------------------------------------------------
point1 <- 14
point2 <- 30

data.frame(x = seq(0, 1, 0.001)) %>%
  dplyr::mutate(y = dbeta(x, 10, 40)) %>%
  ggplot() + theme_minimal() +
  geom_ribbon(aes(x = x*100, ymax = y, ymin = 0), fill = "dodgerblue3", alpha = 0.5) +
  geom_line(aes(x = x*100, y = y)) +
  geom_vline(xintercept = 20, linetype = "dashed") +
  annotate(x = 28, y = 8, geom = "text", label = "p = 20%") +
  geom_point(aes(x = point1, y = 0)) +
  geom_segment(aes(x = point1, y = 1, xend = point1, yend = 0.2),
                  arrow = arrow(length = unit(0.3, "cm"))) +
  annotate(x = point1, y = 1.3, geom = "text", label = "14%") +
  geom_point(aes(x = point2, y = 0)) +
  geom_segment(aes(x = point2, y = 1, xend = point2, yend = 0.2),
                  arrow = arrow(length = unit(0.3, "cm"))) +
  annotate(x = point2, y = 1.3, geom = "text", label = "30%") +
  ylim(c(0, 10)) + xlab("Cluster-level prevalence (%)") + ylab("Probability density")

## -----------------------------------------------------------------------------
get_prevalence(n = n_deletions, N = n_tested)

## ---- echo=FALSE--------------------------------------------------------------
gp <- get_prevalence(n = n_deletions, N = n_tested)

