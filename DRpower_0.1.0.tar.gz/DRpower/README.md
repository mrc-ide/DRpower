
[![master checks](https://github.com/mrc-ide/DRpower/workflows/checks_master/badge.svg)](https://github.com/mrc-ide/DRpower/actions)
[![develop checks](https://github.com/mrc-ide/DRpower/workflows/checks_develop/badge.svg)](https://github.com/mrc-ide/DRpower/actions)

# DRpower

The DRpower package is designed to assist with the development of *Plasmodium
falciparum* *pfhrp2/3* gene deletion studies.

All documentation, including installation instructions and tutorials, are on
[the DRpower website](TODO).


# Version History

This software is currently still in development (as of May 2023). The current development version is v0.1.0.
